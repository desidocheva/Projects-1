#include <iostream>
#include<iomanip>
#include <cstdlib>
using namespace std;

void variant1()
{
    int a[100][100],m,n;
    cout<<"m="; cin>>m;
    cout<<"n="; cin>>n;
    for(int i=0;i<m;i++)
    for(int j=0;j<n;j++)
    {
        cout<<"a["<<i<<"]["<<j<<"]=";
        cin>>a[i][j];
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        cout<<setw(5)<<a[i][j]<<" ";
        cout<<endl;
    }
}
void variant2()
{
    int a[100][100],m,n;
    cout<<"m="; cin>>m;
    cout<<"n="; cin>>n;
    for(int i=0;i<m;i++)
    for(int j=0;j<n;j++)
    {

        a[i][j]=rand()%100;
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        cout<<setw(5)<<a[i][j]<<" ";
        cout<<endl;
    }
}
int main()
{
    int k;
    cout<<"Vuvejdane na chisla ot klaviaturata - 1\nVuvejdane na random chisla - 2"<<endl;
    cout<<"Izberi:"; cin>>k;
    if(k==1) variant1();
    if(k==2)variant2();
    return 0;
}
